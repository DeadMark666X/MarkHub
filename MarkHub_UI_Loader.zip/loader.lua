-- loader.lua
local uiScript = loadstring(game:HttpGet("https://raw.githubusercontent.com/DeadMark666X/MarkHub/main/Ui.lua"))()
uiScript:Init()
